package ser;
import java.util.Map;

import bean.EmployeeDetails;
public interface ServiceInterface {
    public void Cal(EmployeeDetails seobj);
    public void storee(Map alobj);
    public boolean validateName(String empName);
    public boolean validateMobileNum(String mobileNum);
    public boolean validateMail(String empMail);
    
}