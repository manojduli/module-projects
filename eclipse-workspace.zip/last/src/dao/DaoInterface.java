package dao;

 

 

 

import bean.employeeDetails;

 

 

 

public interface DaoInterface {
    public void employeeStorage(EmployeeDetails deobj) ;
}

 