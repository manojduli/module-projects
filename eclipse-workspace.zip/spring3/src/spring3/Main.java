package spring3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	
	public static void main(String args[])
	{
	
		ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		System.out.println("Sbu Details");
		System.out.println("-------------");
		Sbu sb=ctx.getBean(Sbu.class);
		System.out.println(sb);
//		System.out.println("Employee Details");
//		System.out.println("-------------");
//		Employee emp=ctx.getBean(Employee.class);
//		System.out.println(emp);
	}

}