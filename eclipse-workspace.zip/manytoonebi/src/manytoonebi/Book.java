package manytoonebi;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Book {

	@Id
	@GeneratedValue                                   //(strategy=GenerationType.AUTO)
	private int BookId;
	private String BookName;
	
	//@ManyToOne(cascade=CascadeType.ALL)
	//@JoinColumn(name="id")
	//private Author author;
//	public Author getA1() {
//		return author;
//	}
//	public void setA1(Author a1) {
//		this.author = a1;
//	}
	
	
	
	
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getBookName() {
		return BookName;
	}
	public void setBookName(String bookName) {
		BookName = bookName;
	}
	@Override
	public String toString() {
		return "Book [BookId=" + BookId + ", BookName=" + BookName + "]";
	}
	
	
	
}
