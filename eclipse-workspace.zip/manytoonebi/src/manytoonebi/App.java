package manytoonebi;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class App {

	public static void main(String args[])
	{
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		
		Book b1=new Book();
	//	b1.setBookId(1);
		b1.setBookName("Java");
		
		Book b2=new Book();
	//	b2.setBookId(2);
		b2.setBookName("Angular");
		
		
		
		em.persist(b1);
		em.persist(b2);
		
		List<Book> bookList = new ArrayList<>();
		bookList.add(b1);
		bookList.add(b2);
		
		Author author=new Author();
		//author.setAuthorId(1);
		author.setAuthorName("sudheer");
		author.setBook(bookList);
		
		
		em.persist(author);
	
		
		
		
//		a.getBook().add(b1);
//		a.getBook().add(b2);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}
	
	
}
