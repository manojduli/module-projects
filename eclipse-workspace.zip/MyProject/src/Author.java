import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Author {

	public static void main(String args[])
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter Id");
		int authorId =sc.nextInt();
		System.out.println("enter first name");
        String firstName =sc.next();
        System.out.println("enter middle name");
        String middleName=sc.next();
        System.out.println("enter last name");
        String lastName =sc.next();
        System.out.println("enter phone number ");
        int phoneNo =sc.nextInt();
        Bean obj = new Bean();
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em=factory.createEntityManager();
//      
//        obj.setAuthorId(authorId);
//        obj.setFirstName(firstName);
//        obj.setMiddleName(middleName);
//        obj.setLastName(lastName);
//        obj.setPhoneNo(phoneNo);
        em.getTransaction().begin();
        em.persist(obj);
        
        
        Bean o=em.find(Bean.class,103);
        System.out.println("Author ID : "+o.getAuthorId());
        System.out.println("First Name : "+o.getFirstName());     
        
         o.setFirstName("Duli");
        
//          Bean b=em.find(Bean.class,101);
          System.out.println("Author ID : "+obj.getAuthorId());
          System.out.println("First Name : "+obj.getFirstName());
        em.persist(o);
        //em.remove(o);
        em.getTransaction().commit();
        System.out.println("Data added");
        em.close();
 
	}
}