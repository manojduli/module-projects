package ui.com;

import java.util.Scanner;

import bean.com.Bean;
import service.com.ServiceLayer;

public class UiLayer {
	
	public static void main(String args[])
	{
		UiLayer ui=new UiLayer();
		ui.display();
		
	}
	
	public void display() {
	Scanner s=new Scanner(System.in);	
	ServiceLayer sl=new ServiceLayer();

	System.out.println("Enter 1 to Create account");
	System.out.println("Enter 2 to to Show balance");
	System.out.println("Enter 3 to Deposit");
	System.out.println("Enter 4 to withdraw");
	System.out.println("Enter 5 to Fund Transfer");
	System.out.println("Enter 6 to Print Transactions");
	System.out.println("enter your choice");
	int choice=s.nextInt();
	switch(choice)
	{
	case 1:
		
		sl.createAccount();
		break;
	case 2:
		sl.showBalance();
		break;
		
	case 3:
		sl.deposit();
		break;
		
	case 4:
		sl.withDraw();
		break;
		
	case 5:
		sl.fundTransfer();
		break;
	case 6:
		sl.printTransactions();
		break;
	default:
		System.out.println("enter correct entry");
		break;
	}
	}
}

