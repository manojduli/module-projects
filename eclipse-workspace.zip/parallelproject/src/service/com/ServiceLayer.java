package service.com;

import java.util.Scanner;

import bean.com.Bean;

public class ServiceLayer {

Scanner s=new Scanner(System.in);

	public void createAccount()
	{
		
	}
	
	public void showBalance()
	{
		
	}
	public void deposit()
	{
	
	}
	public void withDraw()
	{
		

		}
	public void fundTransfer()
	{
		
		
	}
	public void printTransactions()
	{
	
	}
}
