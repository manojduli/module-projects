package bean.com;

public class Bean {

	private int amount;
	private int balance;
	private String firstName;
	private String lastName;
	

	public Bean(int amount, int min_amt, String firstName, String lastName) {
		super();
		this.amount = amount;
		this.balance = balance;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Bean()
	{
		super();
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getbalance() {
		return balance;
	}
	public void setbalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Bean [amount=" + amount + ", balance=" + balance + ", firstName=" + firstName + ", lastName=" + lastName
				+ "]";
	}
	
	
}
