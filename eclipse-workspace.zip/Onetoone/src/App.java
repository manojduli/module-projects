import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class App {
	
	public static void main(String args[])
	{
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		
		Student s=new Student();
		s.setStudId(1);
		s.setStudName("manoj");
		
		
		
		em.persist(s);	
		
		Book b=new Book();
		b.setBook_id(1);
		b.setBook_name("JEE");
		
		b.setBook_id(2);
		b.setBook_name("JPA");
		
		b.setS1(s);
		em.persist(b);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

}
