package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Bankingexception.BankingException;
import com.cg.bean.BankBean;
import com.cg.service.BankService;

@RestController
public class BankController 
{
    @Autowired
    BankService bankService;
    
    @RequestMapping("/bank/getcustomerDetails/{userName}")
    public BankBean  getCustomers(@PathVariable String userName) throws BankingException
    {
        return bankService.getCustomerDetails(userName);
    }
    
    @RequestMapping(value="/bank/addcustomer", method = RequestMethod.POST)
    public boolean addCustomers(@RequestBody BankBean bank) throws BankingException
    {
        return bankService.addCustomer(bank);
    }
    
    @RequestMapping("/bank/customer/showbalance/{accountId}")
    public long showBalance(@PathVariable int accountId) throws BankingException
    {
        return bankService.showBalance(accountId);
    }
    
    @RequestMapping(value = "/bank/customer/deposit/{accountId}/{amount}",method=RequestMethod.PUT)
    public long depositMoney(@PathVariable int accountId,@PathVariable long amount) throws BankingException
    {
        return bankService.depositMoney(accountId, amount);
    }
    
    @RequestMapping(value = "/bank/customer/withdraw/{accountId}/{amount}",method=RequestMethod.PUT)
    public long withdrawMoney(@PathVariable int accountId,@PathVariable long amount) throws BankingException
    {
        return bankService.withdrawMoney(accountId, amount);
    }
    
    @RequestMapping(value = "/bank/customer/fundtransfer/{accountId1}/{accountId2}/{amount}",method=RequestMethod.PUT)
    public boolean fundTransfer(@PathVariable int accountId1,@PathVariable int accountId2,@PathVariable long amount) throws BankingException
    {
        return bankService.fundTransfer(accountId1, accountId2, amount);
    }
    @RequestMapping(value = "/bank/customer/{userName}/{password}")
    public BankBean loginByUser(@PathVariable("userName")String userName,@PathVariable("password") String password) throws BankingException
    {
        return bankService.loginByUser(userName, password);
    }
}