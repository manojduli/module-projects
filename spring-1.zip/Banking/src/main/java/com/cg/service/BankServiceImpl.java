package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Bankingexception.BankingException;
import com.cg.bean.BankBean;
import com.cg.dao.BankDao;

@Service
public class BankServiceImpl implements BankService{

	@Autowired
	BankDao bankDao;

	@Override
	public boolean addCustomer(BankBean BankBean) throws BankingException {
		try {
			bankDao.save(BankBean);
			return true;
		}
		catch(Exception exception) {
			throw new BankingException(exception.getMessage());
		}
	}


	@Override
	public BankBean getCustomerDetails(String userName) throws BankingException {
		try {
			return  bankDao.getCustomerDetails(userName);
		}catch (Exception exception) {
			throw new BankingException(exception.getMessage());
		}

	}

	@Override
	public BankBean loginByUser(String userName, String password) throws BankingException {
		try {
			return bankDao.loginByUser(userName, password);
		}catch(Exception exception) {
			throw new BankingException(exception.getMessage());
		}
	}

	@Override
	public long depositMoney(int accountId, long amount) throws BankingException {
		try {
			BankBean temp = bankDao.getCustomerById(accountId);
            long currentBalance = temp.getBalance();
            long updatedBalance = amount + currentBalance;
            temp.setBalance(updatedBalance);
            bankDao.save(temp);
            return updatedBalance;
		}
		catch(Exception exception) {
			throw new BankingException(exception.getMessage());
		}


	}

	@Override
	public long withdrawMoney(int accountId, long amount) throws BankingException {
		try {
			BankBean temp = bankDao.getCustomerById(accountId);
            long currentBalance = temp.getBalance();
            long updatedBalance = currentBalance-amount;
            temp.setBalance(updatedBalance);
            bankDao.save(temp);
            return updatedBalance;
			}catch(Exception exception) {
			throw new BankingException(exception.getMessage());
		}

	}

	@Override
	public long showBalance(int accountId) throws BankingException {
		try {
			BankBean temp = bankDao.getCustomerById(accountId);
			return temp.getBalance();
		}
		catch(Exception exception){
			throw new BankingException(exception.getMessage());
		}

	}

	@Override
	public boolean fundTransfer(int accountId1, int accountId2, long amount) throws BankingException {
		try {
			BankBean temp1 = bankDao.getCustomerById(accountId1);
            long currentBalance1 = temp1.getBalance();
            long updatedBalance1 = amount + currentBalance1;
            temp1.setBalance(updatedBalance1);
            bankDao.save(temp1);

			

			BankBean temp2 = bankDao.getCustomerById(accountId2);
            long currentBalance2 = temp2.getBalance();
            long updatedBalance2 = currentBalance2-amount;
            temp2.setBalance(updatedBalance2);
            bankDao.save(temp2);
         
			return true;

		}catch(Exception exception) {
			throw new BankingException(exception.getMessage());
		}
	}
	
	
}
