package com.cg.service;

import com.cg.Bankingexception.BankingException;
import com.cg.bean.BankBean;

public interface BankService {

	public boolean addCustomer(BankBean BankBean) throws BankingException;
	public BankBean getCustomerDetails(String userName) throws BankingException;
	public BankBean loginByUser(String userName,String password) throws BankingException; 
	public long depositMoney(int accountId,long amount) throws BankingException;
	public long withdrawMoney(int accountId,long amount) throws BankingException;
	public long showBalance(int accountId) throws BankingException;
	public boolean fundTransfer(int accountId1,int accountId2, long amount) throws BankingException;
}
