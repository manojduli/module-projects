package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.BankBean;
@Repository
public interface BankDao extends JpaRepository<BankBean,Integer>{

	@Query("from BankBean where userName=:userName")
	BankBean getCustomerDetails(@Param("userName") String userName);
	
	@Query("from BankBean where userName=:userName and password=:password")
	BankBean loginByUser(@Param("userName")String email,@Param("password") String password);
	
	@Query("from BankBean where accountId=:accno")
    BankBean getCustomerById(@Param("accno") int accountNo);
	
}
