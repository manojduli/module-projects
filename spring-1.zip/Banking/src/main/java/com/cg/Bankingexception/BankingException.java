package com.cg.Bankingexception;

public class BankingException extends Exception{

	public BankingException() {
		super();
	}
	public BankingException(String msg) {
		super(msg);
	}


}
