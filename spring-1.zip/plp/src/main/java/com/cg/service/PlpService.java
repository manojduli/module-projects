package com.cg.service;

import java.util.List;

import com.cg.bean.Bean;

public interface PlpService {

	List<Bean> getProductByCategory(String category);
}
