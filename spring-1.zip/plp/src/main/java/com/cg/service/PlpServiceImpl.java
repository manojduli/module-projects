package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Bean;
import com.cg.dao.PlpDao;

@Service
public class PlpServiceImpl implements PlpService {

	@Autowired
	PlpDao dao;
	
	@Override
	public List<Bean> getProductByCategory(String category) {
		
		return dao.getProductByCategory(category);
	}

}
