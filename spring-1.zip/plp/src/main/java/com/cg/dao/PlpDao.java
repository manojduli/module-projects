package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Bean;

@Repository
public interface PlpDao extends JpaRepository<Bean,String>{

	@Query("select * from bean where category:=pro")
	List<Bean> getProductByCategory(@Param("pro")String category);
	

	
	
}
