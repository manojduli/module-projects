package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Bean;
import com.cg.service.PlpService;

@RestController
public class PlpController {
	
	
	@Autowired
	PlpService service;
	
	@RequestMapping(value="/plp/185879/similarproducts/{category",method=RequestMethod.GET)
	public List<Bean> getProductByCategory(@PathVariable String category)
	{
		return service.getProductByCategory(category);
	}

}
