package com.cg.bean;

import java.sql.Time;

public class Bean {
	
	private String proId;
	private String prodName;
	private String prodCategory;
	private double price;
	private int discount;
	private String promocode;
	private String validTime;
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdCategory() {
		return prodCategory;
	}
	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public String getPromocode() {
		return promocode;
	}
	public void setPromocode(String promocode) {
		this.promocode = promocode;
	}
	public String getValidTime() {
		return validTime;
	}
	public void setValidTime(String validTime) {
		this.validTime = validTime;
	}
	@Override
	public String toString() {
		return "Bean [proId=" + proId + ", prodName=" + prodName + ", prodCategory=" + prodCategory + ", price=" + price
				+ ", discount=" + discount + ", promocode=" + promocode + ", validTime=" + validTime + "]";
	} 
	
	
	

}
