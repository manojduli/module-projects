package com.cg.empapp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
@ControllerAdvice
public class EmployeeExceptionHandler {

	public ResponseEntity<String> handleException(Exception ex)
	{
		return new ResponseEntity<String>("Error :"+ex.getMessage(),HttpStatus.CONFLICT);
	}
}
