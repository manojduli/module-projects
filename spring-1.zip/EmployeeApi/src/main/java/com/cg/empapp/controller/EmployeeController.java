package com.cg.empapp.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.empapp.Exception.ProductEmployeeException;
import com.cg.empapp.bean.Employee;
import com.cg.empapp.service.EmployeeService;
@RestController
public class EmployeeController {
    
	//read all
    @Autowired
    EmployeeService employeeService;
    @RequestMapping("/api/employees")
    public List<Employee> getAllEmployee() throws ProductEmployeeException{
        return employeeService.getAllEmployees();
    }
    
    //read by id
    @RequestMapping("/api/employees/{id}")
    public Employee getEmployees(@PathVariable int id)  throws ProductEmployeeException{
        return employeeService.getEmployeeById(id);
        
    }
    
    //delete
    @RequestMapping(value="/api/employees/{id}",method=RequestMethod.DELETE)
    public ResponseEntity<String> deleteEmployee(@PathVariable int id)  throws ProductEmployeeException{
        employeeService.deleteEmployee(id);
        return new ResponseEntity<String>
        ("Employee with the id "+id+"deleted",HttpStatus.OK);
    }
    
    //add
    @RequestMapping(value="/api/employees",method=RequestMethod.POST)
    public ResponseEntity<String> addEmployee(@RequestBody Employee emp)  throws ProductEmployeeException{
        employeeService.addEmployee(emp);
        return new ResponseEntity<String>("Employee Sucessfully added",HttpStatus.OK);
    }
    
    //update
    @RequestMapping(value="/api/employees/{id}",method=RequestMethod.PUT)
    public ResponseEntity<String> updateEmployee(@RequestBody Employee emp)  throws ProductEmployeeException{
        employeeService.updateEmployee(emp);
        return new ResponseEntity<String>("Employee Sucessfully updated",HttpStatus.OK);
    }
    //gender
    @RequestMapping("/api/employees/gender")
    public List<Employee> getEmployeeByGender(@RequestParam String gender) throws ProductEmployeeException
    {
    	return employeeService.getEmployeeByGender(gender);
    }
    
    @ExceptionHandler(ProductEmployeeException.class)
    public ResponseEntity<String> handleErrors(Exception ex)
    {
    	return new ResponseEntity<String>("An error occured "+ex.getMessage(),HttpStatus.CONFLICT);
    }
}
 