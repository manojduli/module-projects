package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.Exception.ProductEmployeeException;
import com.cg.empapp.bean.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees() throws ProductEmployeeException;
	Employee getEmployeeById(int id) throws ProductEmployeeException;
	void updateEmployee(Employee emp) throws ProductEmployeeException;
	void addEmployee(Employee emp) throws ProductEmployeeException;
	void deleteEmployee(int id) throws ProductEmployeeException;
	List<Employee> getEmployeeByGender(String gender) throws ProductEmployeeException;
}
