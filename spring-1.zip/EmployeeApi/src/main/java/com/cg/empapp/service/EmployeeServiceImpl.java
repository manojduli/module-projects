package com.cg.empapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empapp.Exception.ProductEmployeeException;
import com.cg.empapp.bean.Employee;
import com.cg.empapp.dao.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	@Override
	public List<Employee> getAllEmployees() throws ProductEmployeeException {
		try {
		return employeeDao.findAll();
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}
	
	@Override
	public Employee getEmployeeById(int id)  throws ProductEmployeeException{
	
		try {
		return employeeDao.findById(id).get();
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}
	
	//update employee
	@Override
	public void updateEmployee(Employee emp) throws ProductEmployeeException {
		try
		{
		employeeDao.save(emp);
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}
	
	//add employee
	@Override
	public void addEmployee(Employee emp) throws ProductEmployeeException {
		try
		{
		employeeDao.save(emp);
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}
	//delete
	@Override
	public void deleteEmployee(int id) throws ProductEmployeeException {
		try {
		employeeDao.deleteById(id);
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}
	//by gender
	@Override
	public List<Employee> getEmployeeByGender(String gender) throws ProductEmployeeException {
		try
		{
		return employeeDao.getEmployeeByGender(gender);
		}
		catch(Exception e)
		{
			throw new ProductEmployeeException(e.getMessage());
		}
	}

}
