package com.capg.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimilarProducts185879Application {

	public static void main(String[] args) {
		SpringApplication.run(SimilarProducts185879Application.class, args);
	}

}
