package com.capg.exception;

public class ProductException extends Exception{
	
public ProductException() {
		
	}
	public ProductException(String msg)
	{
		super(msg);
	}
	


}
