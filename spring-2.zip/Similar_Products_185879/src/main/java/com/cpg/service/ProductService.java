package com.cpg.service;

import java.util.List;

import com.capg.bean.Product;
import com.capg.exception.ProductException;

public interface ProductService {
	
	List<Product> getProductByCategory(String prodCategory) throws ProductException;

}
