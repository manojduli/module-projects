package com.cg.sess.service;

import java.util.List;

import com.cg.sess.Exception.SessionnException;
import com.cg.sess.bean.Sessionn;

public interface SessionService {

	public List<Sessionn> getAllSessions() throws SessionnException;
	public Sessionn getSessionById(int id) throws SessionnException;
	public void addSession(Sessionn sess) throws SessionnException;
	public void deleteSession(int id) throws SessionnException;
    List<Sessionn> updateSession(int id,Sessionn sess) throws SessionnException;
}
