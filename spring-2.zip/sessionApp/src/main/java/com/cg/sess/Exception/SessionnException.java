package com.cg.sess.Exception;

public class SessionnException extends Exception{
	
public SessionnException() {
	
}
public SessionnException(String msg)
{
	super(msg);
}
	

}
