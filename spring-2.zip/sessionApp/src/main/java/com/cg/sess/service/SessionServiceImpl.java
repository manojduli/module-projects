package com.cg.sess.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sess.Exception.SessionnException;
import com.cg.sess.bean.Sessionn;
import com.cg.sess.dao.SessionDao;

@Service
public class SessionServiceImpl implements SessionService{

	@Autowired
	SessionDao sessionDao;
	//get all
	@Override
	public List<Sessionn> getAllSessions() throws SessionnException{
		try {
		return sessionDao.findAll();
		}
		catch(Exception e)
		{
			throw new SessionnException(e.getMessage());
		}
	}
	// by id
	@Override
	public Sessionn getSessionById(int id) throws SessionnException{
		try
		{
		return sessionDao.findById(id).get();
		}
		catch(Exception e)
		{
			throw new SessionnException(e.getMessage());
		}
	}
	//add
	@Override
	public void addSession(Sessionn sess) throws SessionnException {
		try {
			
		sessionDao.save(sess);
		}
		catch(Exception e) {
			throw new SessionnException(e.getMessage());
		}
	}
	//delete
	@Override
	public void deleteSession(int id) throws SessionnException{
		try {
		sessionDao.deleteById(id);
		}
		catch(Exception e) {
			throw new SessionnException(e.getMessage());
		}
	}
	
	//update
	@Override
	public List<Sessionn> updateSession(int id,Sessionn sess) throws SessionnException
	{
		try
		{
			Optional<Sessionn> optional=sessionDao.findById(id);
		
			if(optional.isPresent()) 
			{
				Sessionn session=optional.get();
				session.setDuration(sess.getDuration());
				session.setModel(sess.getModel());
				sessionDao.save(session);
				return getAllSessions();
			}
			else
			{
			throw new SessionnException( + id + "does not exist.");
			}
		}
		catch(Exception e)
		{
			throw new SessionnException(e.getMessage());
		}
	}
	
	
	
	

	
		
	}


