package com.cg.iproduct.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.iproduct.Dao.IproductRepo;
import com.cg.iproduct.Exception.ProductException;
import com.cg.iproduct.bean.Product;

@Service
public class IproductServiceImpl implements IproductService{

	
	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for create, 
     */
	
	@Autowired
	IproductRepo iproductRepo;
	//create
	@Override
	public void CreateProduct(Product prod) throws ProductException{
		try {
		iproductRepo.save(prod);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}
	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for  update
     */
	
	//update
	@Override
	public void updateProduct(Product prod,String id) throws ProductException {
		try
		{
		iproductRepo.save(prod);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}
	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for delete
     */
	
	//delete
	@Override
	public void deleteProduct(String id) throws ProductException{
		try
		{
		iproductRepo.deleteById(id);
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}
	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for get all products
     */
	
	//get all
	@Override
	public List<Product> getAllProducts() throws ProductException{
		try
		{
		return iproductRepo.findAll();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}
	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for get product by id
     */
	
	//by id
	@Override
	public Product getProductById(String id) throws ProductException{
		try
		{
		return iproductRepo.findById(id).get();
		}
		catch(Exception e)
		{
			throw new ProductException(e.getMessage());
		}
	}

	
}
