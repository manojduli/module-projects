package com.cg.iproduct.service;

import java.util.List;

import com.cg.iproduct.Exception.ProductException;
import com.cg.iproduct.bean.Product;

public interface IproductService {

	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for create, update,delete,get all products,get product by id
     */
	
	public void CreateProduct(Product prod) throws ProductException;
	public void updateProduct(Product prod,String id) throws ProductException;
	public void deleteProduct(String id) throws ProductException;
	List<Product> getAllProducts() throws ProductException;
	 Product getProductById(String id) throws ProductException;

}