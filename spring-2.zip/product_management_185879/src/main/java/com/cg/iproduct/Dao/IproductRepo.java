package com.cg.iproduct.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.iproduct.bean.Product;

@Repository
public interface IproductRepo extends JpaRepository<Product,String> {

	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: dao layer
     */
	

}
