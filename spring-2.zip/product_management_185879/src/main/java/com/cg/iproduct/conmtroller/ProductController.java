package com.cg.iproduct.conmtroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.iproduct.Exception.ProductException;
import com.cg.iproduct.bean.Product;
import com.cg.iproduct.service.IproductService;

@RestController
public class ProductController {

	/***
     * Author:duli venkat manoj
     * Date Of Creation: 30-07-2019
     
     * Purpose: methods for create, update,delete,get all products,get product by id in controller
     */
	
	@Autowired
	IproductService service; 
	@RequestMapping(value="/createproduct",method=RequestMethod.POST)
	public ResponseEntity<String> CreateProduct(@RequestBody Product prod) throws ProductException{
		
		service.CreateProduct(prod);
		return new ResponseEntity<String>("Product Successfully added",HttpStatus.OK);
	}
	
	@RequestMapping(value="/updateproduct/{id}",method=RequestMethod.PUT)
	public ResponseEntity<String> updateProduct(Product prod,@RequestBody String id) throws ProductException {
		service.updateProduct(prod,id);
		return new ResponseEntity<String>("Product updated successfully",HttpStatus.OK);
	}
	
	@RequestMapping(value="/deleteproduct/{id}",method=RequestMethod.DELETE)
	public ResponseEntity<String> deleteProduct(@PathVariable String id) throws ProductException{
		service.deleteProduct(id);
		return new ResponseEntity<String>("Product with"+id+" deleted",HttpStatus.OK);
	}
	
	@RequestMapping(value="/products",method=RequestMethod.GET)
	public List<Product> getAllProducts() throws ProductException{
		
		return service.getAllProducts();
	}
	
	@RequestMapping("/productbyid/{id}")
	public Product getProductById(String id) throws ProductException
	{
		return service.getProductById(id);
	}
	
//	@ExceptionHandler(ProductExceptionHandler.class)
//    public ResponseEntity<String> handleErrors(Exception ex)
//    {
//    	return new ResponseEntity<String>("An error occured "+ex.getMessage(),HttpStatus.CONFLICT);
//    }
//	
	
}
