package com.cg.iproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/***
 * Author: Duli venkat manoj
 * Date Of Creation: 30-07-2019
 */
@SpringBootApplication
public class ProductManagement185879Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagement185879Application.class, args);
	}

}
